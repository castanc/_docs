﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace FullTrust
{
    class Program
    {
        public class Point
        {
            public int X { set; get; }
            public int Y { set; get; }

            public Point(int x, int y)
            {
                X = x;
                Y = y;
            }
        }
        public class Locator
        {
            [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
            static extern IntPtr FindWindowByCaption(IntPtr ZeroOnly, string lpWindowName);

            [DllImport("user32.dll", SetLastError = true)]
            [return: MarshalAs(UnmanagedType.Bool)]
            internal static extern bool GetWindowPlacement(IntPtr hWnd, out WINDOWPLACEMENT lpwndpl);

            [DllImport("user32.dll", SetLastError = true)]
            [return: MarshalAs(UnmanagedType.Bool)]
            static extern bool SetWindowPlacement(IntPtr hWnd,
               [In] ref WINDOWPLACEMENT lpwndpl);

            [DllImport("user32.dll", SetLastError = true)]
            public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out UInt32 lpdwProcessId);


            [Serializable]
            [StructLayout(LayoutKind.Sequential)]
            internal struct WINDOWPLACEMENT
            {
                public int Length;
                public int Flags;
                public ShowWindowCommands ShowCmd;
                public POINT MinPosition;
                public POINT MaxPosition;
                public RECT NormalPosition;
                public static WINDOWPLACEMENT Default
                {
                    get
                    {
                        WINDOWPLACEMENT result = new WINDOWPLACEMENT();
                        result.Length = Marshal.SizeOf(result);
                        return result;
                    }
                }
            }

            internal enum ShowWindowCommands : int
            {
                Hide = 0,
                Normal = 1,
                ShowMinimized = 2,
                Maximize = 3,
                ShowMaximized = 3,
                ShowNoActivate = 4,
                Show = 5,
                Minimize = 6,
                ShowMinNoActive = 7,
                ShowNA = 8,
                Restore = 9,
                ShowDefault = 10,
                ForceMinimize = 11
            }

            [StructLayout(LayoutKind.Sequential)]
            public struct POINT
            {
                public int X;
                public int Y;

                public POINT(int x, int y)
                {
                    this.X = x;
                    this.Y = y;
                }

                public static implicit operator Point(POINT p)
                {
                    return new Point(p.X, p.Y);
                }

                public static implicit operator POINT(Point p)
                {
                    return new POINT(p.X, p.Y);
                }
            }

            [StructLayout(LayoutKind.Sequential)]
            public struct RECT
            {
                private int _Left;
                private int _Top;
                private int _Right;
                private int _Bottom;
            }

            public IntPtr FindWindow(string text, int mode = 2, string commandLine = "")
            {
                int result = -1;
                // Get the target window's handle.
                IntPtr target_hwnd = FindWindowByCaption(IntPtr.Zero, text);
                if (target_hwnd == IntPtr.Zero)
                {
                    return IntPtr.Zero;
                }


                // Prepare the WINDOWPLACEMENT structure.
                WINDOWPLACEMENT placement = new WINDOWPLACEMENT();
                placement.Length = Marshal.SizeOf(placement);

                // Get the window's current placement.
                GetWindowPlacement(target_hwnd, out placement);

                // Set the placement's action.
                if (mode == 0)
                    placement.ShowCmd = ShowWindowCommands.ShowMaximized;
                else if (mode == 1)
                    placement.ShowCmd = ShowWindowCommands.ShowMinimized;
                else
                    placement.ShowCmd = ShowWindowCommands.Normal;

                // Perform the action.
                SetWindowPlacement(target_hwnd, ref placement);
                result = 0;
                return target_hwnd;
            }

        }



        static void Main(string[] args)
        {

            var locator = new Locator();
            IntPtr hwnd = locator.FindWindow("TCS DeskHelp Dev 2", 1);
            //hwnd = locator.FindWindow("TCS DeskHelp Dev 2", 2);

            UInt32 processid = 0;
            UInt32 threadid = Locator.GetWindowThreadProcessId(hwnd, out processid);

            var procs = Process.GetProcessesByName("chrome");



            if ( hwnd != IntPtr.Zero)
            {
                try
                {


                    int procPtr = (int)processid;
                    Process processFromID = Process.GetProcessById(procPtr);


                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("PWC PROCESS:" + processFromID.Handle.ToString());

                    foreach (var p in procs)
                        sb.AppendLine(p.Id.ToString()+ " ");

                    string s = sb.ToString();

                    //processFromID.Kill();
                }
                catch (Exception ex)
                {

                }
            }

            Console.Title = "Hello World";
            string strCmdText = "\"" + @"C:\Program Files (x86)\Google\Chrome\Application\chrome_proxy.exe" + "\"";
            strCmdText = strCmdText + " --profile-directory=Default --app-id=andoncijbhadleiidjpjdcdjhnainali";


            //strCmdText = @"C:\cesar\UWP-FullTrust\WinFormsWindowLocator\WinFormsWindowLocator\bin\Debug\WinFormsWindowLocator.exe";
            ProcessStartInfo procStartInfo = new ProcessStartInfo("cmd", "/c " + strCmdText);
            //procStartInfo.UseShellExecute = true;
            //procStartInfo.CreateNoWindow = false;
            Process process = new Process();
            process.StartInfo = procStartInfo;
            process.Start();

            

        }
    }
}
