﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsWindowLocator
{
    static class Program
    {

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            var frm = new Form1();
            frm.OnCloseWindwos += Frm_OnCloseWindwos;
            //frm.Top = Screen.AllScreens[0].Bounds.Height + 100;
            frm.FormBorderStyle = FormBorderStyle.None;
            frm.Show();
            var result= frm.findWindow();
            //Application.Run(frm);
        }

        private static void Frm_OnCloseWindwos(Form frm, int value)
        {
            if (value <0 )
                Application.Exit();
            else if ( value == 2 )
            {
                var result = frm.FindForm();
                Application.Exit();
            }
                    
        }
    }
}
