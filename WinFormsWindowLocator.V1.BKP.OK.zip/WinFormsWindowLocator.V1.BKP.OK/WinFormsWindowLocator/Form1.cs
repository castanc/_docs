﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowLocator;

namespace WinFormsWindowLocator
{
    public delegate void delegateCloseWindow(Form frm, int value);
    public partial class Form1 : Form
    {
        public bool launched = false;
        public event delegateCloseWindow OnCloseWindwos;

        public Form1()
        {
            InitializeComponent();
            //var result = findWindow();
            //while (!launched) { };
            //OnCloseWindwos?.Invoke(result);
        }


        public int findWindow()
        {
            var locator = new Locator();
            var result = locator.FindWindow(txWindowName.Text, 1);
            result = locator.FindWindow(txWindowName.Text, 2);
            Console.WriteLine("Find window result:" + result.ToString());
            if (result < 0)
            {
                string strCmdText = "\"" + @"C:\Program Files (x86)\Google\Chrome\Application\chrome_proxy.exe" + "\"";
                strCmdText = strCmdText + " --profile-directory=Default --app-id=andoncijbhadleiidjpjdcdjhnainali";
                ProcessStartInfo procStartInfo = new ProcessStartInfo("cmd", "/c " + strCmdText);

                Process process = new Process();
                process.StartInfo = procStartInfo;
                process.Start();
            }
            launched = true;
            return result;
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            findWindow();
            Close();
            //OnCloseWindwos?.Invoke(0);
            //Application.Exit();
        }
    }
}
